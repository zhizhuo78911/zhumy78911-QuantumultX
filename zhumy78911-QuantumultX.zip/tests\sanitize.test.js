/**
 * 红果去广告脚本单元测试
 * 运行：node tests/sanitize.test.js
 * 说明：用 node:vm 模拟 Quantumult X 的运行环境（$response / $request / $done）
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const SRC = fs.readFileSync(
  path.join(__dirname, '..', 'hongguo-ad.js'),
  'utf8'
);

/** 在沙箱里跑一遍脚本，模拟 QX 收到一次响应 */
function run(body, url) {
  let result = null;
  let doneCalled = false;
  const sandbox = {
    $response: { body: typeof body === 'string' ? body : JSON.stringify(body) },
    $request: { url: url || 'https://api5-normal-lf.fqnovel.com/reading/bookapi/detail/v/' },
    $done: (obj) => {
      doneCalled = true;
      result = obj;
    },
    console: { log: () => {} },
  };
  vm.createContext(sandbox);
  vm.runInContext(SRC, sandbox, { filename: 'hongguo-ad.js' });
  return { result, doneCalled };
}

let passed = 0;

/** $done({}) 表示“原样返回、不做修改” */
function assertUnchanged(result) {
  assert.ok(result && typeof result === 'object', '应调用 $done');
  assert.strictEqual(
    Object.keys(result).length,
    0,
    '$done({}) 不应携带 body，实际为 ' + JSON.stringify(result)
  );
}

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log('  ok   ' + name);
  } catch (e) {
    console.log('  FAIL ' + name);
    console.log('       ' + e.message);
    process.exitCode = 1;
  }
}

console.log('红果去广告脚本测试');

// 1. 列表里的广告条目应被删除，正常条目保留
test('数组中的广告条目会被删除', () => {
  const body = {
    code: 0,
    data: {
      book_list: [
        { book_id: '1001', title: '正经短剧' },
        { book_id: '1002', title: '广告推广', ad_type: 1, ad_info: { id: 9 } },
        { book_id: '1003', title: '正经短剧2' },
      ],
    },
  };
  const { result } = run(body);
  const list = JSON.parse(result.body).data.book_list;
  assert.strictEqual(list.length, 2);
  assert.deepStrictEqual(list.map((x) => x.book_id), ['1001', '1003']);
});

// 2. 广告字段应被摘掉，同级的正常字段要留下
test('广告字段被删除且不影响同层字段', () => {
  const body = { data: { book_id: '2001', title: '剧名', ad_info: { url: 'x' }, ad_type: 2 } };
  const { result } = run(body);
  const out = JSON.parse(result.body).data;
  assert.strictEqual(out.book_id, '2001');
  assert.strictEqual(out.title, '剧名');
  assert.strictEqual('ad_info' in out, false);
  assert.strictEqual('ad_type' in out, false);
});

// 3. ad_type = 0 表示不是广告，这个字段本身必须保留
test('ad_type 为 0 的字段保留', () => {
  const body = {
    data: {
      list: [
        { item_id: '1', ad_type: 0 },
        { item_id: '2', ad_url: 'http://ad/x' },
      ],
    },
  };
  const { result } = run(body);
  const list = JSON.parse(result.body).data.list;
  assert.strictEqual(list.length, 2, 'ad_type=0 的条目不是广告，不能被删');
  assert.strictEqual(list[0].ad_type, 0, 'ad_type=0 是正常值，字段要保留');
  assert.strictEqual('ad_url' in list[1], false, 'ad_url 属于广告字段，应删除');
});

// 4. 不要误伤 address / advance / adaptive 这类正常字段
test('不误删 address / advance / adaptive 等正常字段', () => {
  const body = {
    data: {
      address: '北京市',
      advance: 3,
      adaptive: true,
      advertise: '广告词（非字段名，属正常文本）',
    },
  };
  const { result } = run(body);
  assert.strictEqual(result.body, undefined, '不应该发生任何修改');
});

// 5. 没有任何广告的响应必须原样返回（$done({})）
test('无广告响应原样返回', () => {
  const body = { code: 0, data: { book_list: [{ book_id: '3001' }] } };
  const { result, doneCalled } = run(body);
  assert.ok(doneCalled);
  assertUnchanged(result);
});

// 6. 非 JSON 内容（HTML / 纯文本）原样返回
test('非 JSON 响应原样返回', () => {
  const { result } = run('<html><body>not json</body></html>');
  assertUnchanged(result);
});

// 7. 非法 JSON 不得报错，原样返回
test('非法 JSON 不抛出异常', () => {
  const { result } = run('{"data": ');
  assertUnchanged(result);
});

// 8. 空 body / 空对象
test('空 body 与空对象安全', () => {
  assertUnchanged(run('').result);
  assertUnchanged(run({}).result);
  assertUnchanged(run([]).result);
});

// 9. 深层嵌套里的广告条目也要清掉
test('深层嵌套广告条目被清理', () => {
  const body = {
    data: {
      modules: [
        { type: 'feed', items: [{ id: 'a' }, { id: 'b', is_ad: true }] },
        { type: 'banner', items: [{ id: 'c' }] },
      ],
    },
  };
  const { result } = run(body);
  const modules = JSON.parse(result.body).data.modules;
  assert.strictEqual(modules[0].items.length, 1);
  assert.strictEqual(modules[0].items[0].id, 'a');
  assert.strictEqual(modules[1].items.length, 1);
});

// 10. 广告字段值本身是数组/对象也要清理
test('ad_data / ad_style 等复杂字段被清理', () => {
  const body = {
    data: {
      item_id: '4001',
      ad_data: { creatives: [1, 2, 3] },
      ad_style: 'full_screen',
      ad_slot_id: 'x1',
    },
  };
  const { result } = run(body);
  const out = JSON.parse(result.body).data;
  assert.deepStrictEqual(Object.keys(out), ['item_id']);
});

// 11. 真实感响应：红果详情接口里混入广告位
test('模拟红果详情接口清理效果', () => {
  const body = {
    code: 0,
    message: 'success',
    data: {
      book_id: '7100000001',
      book_name: '被网友玩坏的穿越剧',
      episode_list: [
        { item_id: 'e1', index: 1, duration: 92 },
        { item_id: 'e2', index: 2, duration: 88, ad_type: 3, ad_info: { video_url: 'http://ad/x.flv' } },
        { item_id: 'e3', index: 3, duration: 95 },
      ],
      ad_pattern_info: { pattern: 'splash' },
    },
  };
  const { result } = run(body);
  const data = JSON.parse(result.body).data;
  assert.strictEqual(data.episode_list.length, 2);
  assert.strictEqual(data.book_name, '被网友玩坏的穿越剧');
  assert.strictEqual('ad_pattern_info' in data, false);
});

// 12. 单元测试导出接口可用
test('模块导出可供复用', () => {
  const mod = require(path.join(__dirname, '..', 'hongguo-ad.js'));
  const obj = { data: { list: [{ id: 1 }, { id: 2, is_ad: 1 }] } };
  mod.sanitize(obj);
  assert.strictEqual(obj.data.list.length, 1);
  assert.ok(mod.AD_KEYS.indexOf('ad_info') !== -1);
});

console.log('\n通过 ' + passed + ' 项');
